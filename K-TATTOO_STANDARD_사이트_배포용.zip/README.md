# K-TATTOO STANDARD 사이트

이 폴더는 문신사법 합법영업 준비센터의 첫 검증용 정적 사이트입니다.

## 파일

- `index.html`: 사이트 화면
- `styles.css`: 디자인
- `form-links.js`: Google Form 공유 링크 설정
- `app.js`: 설정된 Google Form 링크를 버튼에 연결하는 기능
- `assets/hero-operations.png`: 생성형 이미지 기반 히어로 이미지
- `consent-demo.html`: 사이트 안에서 바로 열리는 전자동의서 데모
- `resources/checklist.md`: 사이트 안에서 바로 열리는 체크리스트 원문
- `privacy.html`: 개인정보 수집 및 이용 안내 초안
- `GOOGLE_FORM_설정가이드.md`: Google Form 생성 문항과 연결 방법
- `발송자료_가이드.md`: Google Form 응답자에게 보낼 자료와 메시지
- `resources/free-checklist.html`: 무료자료 신청자 발송용 자료
- `resources/survey-thankyou.html`: 실태조사 응답자 발송용 안내
- `resources/beta-guide.html`: 베타 신청자 발송용 안내

## 사용 방법

`index.html`을 브라우저에서 열면 바로 사용할 수 있습니다. 서버는 필요하지 않습니다.

현재 버전은 개인정보를 사이트에 직접 저장하지 않고 Google Form으로 보냅니다. 실제 외부 배포 전에는 개인정보처리방침, 수집/이용 동의 문구, 약관, 보안 검토가 필요합니다.

## Google Form 링크 연결

`form-links.js`에서 아래 값을 실제 Google Form 공유 링크로 바꾸세요.

```js
window.KTS_FORM_LINKS = {
  checklist: '무료자료 신청 Google Form URL',
  survey: '실태조사 Google Form URL',
  beta: '베타 신청 Google Form URL'
};
```

링크를 넣기 전에는 사이트 버튼을 눌러도 안내 메시지만 표시됩니다.

## 연결된 자료

사이트의 전자동의서 버튼은 같은 폴더의 `consent-demo.html`로 연결됩니다.

체크리스트 원문 버튼은 `resources/checklist.md`로 연결됩니다.

무료자료 발송은 Google Form 응답 시트에서 수동 발송하거나, 추후 이메일 자동화 도구와 연결하면 됩니다.
