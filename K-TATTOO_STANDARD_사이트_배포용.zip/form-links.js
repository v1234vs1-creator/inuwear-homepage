window.KTS_FORM_LINKS = {
  checklist: 'https://docs.google.com/forms/d/e/1FAIpQLSfASWedHkxclZzzJp3RW0KXLczxDFGQdEQWFwVcb0IsyT76BA/viewform?usp=sf_link',
  survey: 'https://forms.gle/xXVKZLDbahg72d69A',
  beta: 'https://forms.gle/TAbuLHyapugMwq7N6'
};
