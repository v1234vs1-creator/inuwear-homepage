const FORM_LABELS = {
  checklist: '무료자료 신청',
  survey: '실태조사',
  beta: '베타 신청'
};

const FORM_LINKS = window.KTS_FORM_LINKS || {};
const toast = document.getElementById('toast');

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

function isReadyLink(url) {
  return /^https?:\/\//.test(url || '') && !url.includes('REPLACE_');
}

document.querySelectorAll('[data-form-key]').forEach(link => {
  const key = link.dataset.formKey;
  const url = FORM_LINKS[key];

  if (isReadyLink(url)) {
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    return;
  }

  link.href = '#';
  link.classList.add('is-disabled');
  link.setAttribute('aria-disabled', 'true');
  link.addEventListener('click', event => {
    event.preventDefault();
    showToast(`${FORM_LABELS[key] || '폼'} 링크를 form-links.js에 먼저 넣어주세요.`);
  });
});
